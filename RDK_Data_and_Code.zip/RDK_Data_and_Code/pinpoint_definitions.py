import pandas as pd
import math
import numpy as np
import os
import re
from scipy.stats import norm

def show_target(deg, radius):
    x_trig = np.sin(np.radians(deg))
    y_trig = np.cos(np.radians(deg))
    x_targ = radius*x_trig
    y_targ = radius*y_trig
    return (x_targ, y_targ)

rad = 400

def angle(vector1, vector2):
    x1, y1 = vector1
    x2, y2 = vector2
    inner_product = x1*x2 + y1*y2
    len1 = math.hypot(x1, y1)
    len2 = math.hypot(x2, y2)
    if x1*y2-x2*y1 < 0:
        return math.acos(inner_product/(len1*len2))*180/np.pi
    else:
        return (math.acos(inner_product/(len1*len2))*180/np.pi)*-1
    
def process_df(df, pid, participant_id_column):
    #remove NaN values
    df=df[df['X Coordinate'].notna()]
    
    #separate by participant
    xcoord_norm = []
    ycoord_norm = []
    df_split = []
    vids = []
    actual_angles = []
    angle_coords = []
    delta_angle = []
    
    for i in range(len(pid)):
        df_split.append(df[df[participant_id_column]==pid[i]])
    
    #translate to new origin
    for i in range(len(pid)):
        xcoord_norm.append(df_split[i]['X Coordinate']-400)
        ycoord_norm.append(400-df_split[i]['Y Coordinate'])
        #print(xcoord_norm.head(), ycoord_norm.head())
        vids.append(df_split[i]['video'].values.tolist())
        actual_angles_j = []
        angle_coords_j = []
        delta_angle_j = []
        for j in range(len(xcoord_norm[i])):
            actual_angles_j.append(int(str(re.sub('\D', '', vids[i][j]))[:-1])) #removes the letters and the last digit in .mp4
            angle_coords_j.append(show_target(actual_angles_j[j],rad))
            delta_angle_j.append(angle(angle_coords_j[j],[xcoord_norm[i].iloc[j],ycoord_norm[i].iloc[j]]))
        actual_angles.append(actual_angles_j)
        angle_coords.append(angle_coords_j)
        delta_angle.append(delta_angle_j)
    return (xcoord_norm, ycoord_norm, df_split, vids, actual_angles, angle_coords, delta_angle)

def process_df_elim2digits(df, pid, participant_id_column):
    #remove NaN values
    df=df[df['X Coordinate'].notna()]
    
    #separate by participant
    xcoord_norm = []
    ycoord_norm = []
    df_split = []
    vids = []
    actual_angles = []
    angle_coords = []
    delta_angle = []
    
    for i in range(len(pid)):
        df_split.append(df[df[participant_id_column]==pid[i]])
    
    #translate to new origin
    for i in range(len(pid)):
        xcoord_norm.append(df_split[i]['X Coordinate']-400)
        ycoord_norm.append(400-df_split[i]['Y Coordinate'])
        #print(xcoord_norm.head(), ycoord_norm.head())
        vids.append(df_split[i]['video'].values.tolist())
        actual_angles_j = []
        angle_coords_j = []
        delta_angle_j = []
        for j in range(len(xcoord_norm[i])):
            oops = (int(str(re.sub('\D', '', vids[i][j]))[:-1])) #removes the letters and the last digit in .mp4
            oops_str = str(oops)
            result = oops_str[2:]
            actual_angles_j.append(int(result))
            #print(actual_angles_j)
            angle_coords_j.append(show_target(actual_angles_j[j],rad))
            delta_angle_j.append(angle(angle_coords_j[j],[xcoord_norm[i].iloc[j],ycoord_norm[i].iloc[j]]))
        actual_angles.append(actual_angles_j)
        angle_coords.append(angle_coords_j)
        delta_angle.append(delta_angle_j)
    return (xcoord_norm, ycoord_norm, df_split, vids, actual_angles, angle_coords, delta_angle)

def gauss_param_est(data, m_hyps, s_hyps):
    array = np.zeros((len(m_hyps),len(s_hyps)))
    marg = np.zeros(len(m_hyps))
    marg_s = np.zeros(len(s_hyps))
    for i in range(len(m_hyps)):
        for j in range(len(s_hyps)):
            d = []
            for k in range(len(data)):
                d.append(norm.pdf(data[k], m_hyps[i], s_hyps[j]))
            array[i,j] = np.prod(d)
        marg[i] = np.sum(array[i])
    return array, marg

def transp_marg(array):
    array=array.transpose(1,0)
    marg_s = []
    for i in range(len(array)):
        print(array[i])
        marg_s.append(np.sum(array[i]))
    return marg_s

def do_bayes(pid, m_hyps, s_hyps, delta_angle):
    array = []
    marg = []
    marg_s = []

    for i in range(len(pid)):
        array_i = []
        marg_i = []
        marg_i_s = []
        array_i, marg_i = gauss_param_est(delta_angle[i], m_hyps, s_hyps)
        marg.append(marg_i) #marginalized over s
        marg_i_s = transp_marg(array_i) #marginalized over mu
        marg_s.append(marg_i_s)
        if i < 1:
            array = array_i
        else:
            array = np.dstack((array,array_i))
    return array, marg, marg_s


#print(array.shape, array[:,:,0].shape)   

def gauss_param_est_eps(data, m_hyps, s_hyps):
    array = np.zeros((len(m_hyps),len(s_hyps)))
    marg = np.zeros(len(m_hyps))
    marg_s = np.zeros(len(s_hyps))
    for i in range(len(m_hyps)):
        for j in range(len(s_hyps)):
            d = []
            for k in range(len(data)):
                d.append(0.95*(norm.pdf(data[k], m_hyps[i], s_hyps[j]))+0.5*(1/360))
            array[i,j] = np.prod(d)
        marg[i] = np.sum(array[i])
    return array, marg

def do_bayes_eps(pid, m_hyps, s_hyps, delta_angle):
    array = []
    marg = []
    marg_s = []

    for i in range(len(pid)):
        array_i = []
        marg_i = []
        marg_i_s = []
        array_i, marg_i = gauss_param_est_eps(delta_angle[i], m_hyps, s_hyps)
        marg.append(marg_i) #marginalized over s
        marg_i_s = transp_marg(array_i) #marginalized over mu
        marg_s.append(marg_i_s)
        if i < 1:
            array = array_i
        else:
            array = np.dstack((array,array_i))
    return array, marg, marg_s

def descending_sort(y):
    sorted_indices_ascending = np.argsort(y)
    sorted_indices_descending = sorted_indices_ascending[::-1]
    sorted_y = y[sorted_indices_descending]
    return sorted_y, sorted_indices_descending

def find_shortest_95(x,y): 
    sorted_y, sorted_i = descending_sort(y)
    total = [0]
    x_vals = []
    for i in range(len(y)):
        temp_array = sorted_y/sum(sorted_y)
        total +=temp_array[i]
        x_vals.append(x[sorted_i[i]])
        if total>= 0.95:
            print(total, min(x_vals), max(x_vals))
            return total, min(x_vals), max(x_vals)
            break
        #print(total)

def bayes_prob_greater(y, y2):
    if len(y)==len(y2):
        result = 0
        res_list = []
        for i in range(len(y)):
            prod = y[i] * sum(y2[(i+1):len(y2)])
            result = result + prod
            res_list.append(prod)
        print(result)
        return result
    else:
        print("mismatched bins")
        return np.nan